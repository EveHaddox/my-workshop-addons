est = {}

est.suits = {
    suit_1 = function(ply) ply:SetArmor(0) ply:SetMaxArmor(100) end,
    suit_2 = function(ply) ply:SetArmor(0) ply:SetMaxArmor(100) end,
    suit_3 = function(ply) ply:SetArmor(0) ply:SetMaxArmor(100) end,
    suit_4 = function(ply) ply:SetWalkSpeed(160) ply:SetRunSpeed(240) end,
    suit_5 = function(ply) ply:SetWalkSpeed(160) ply:SetRunSpeed(240) end
    //(file name) = function(ply) (actions on dropping) end
}
// (file name) - the name of the folder of the suit in esuits\lua\entities
// to add new suits the shared.lua file must be edited

est.theme = {
    bg = Color(42, 44, 51),
    txt = Color(233,233,233),
}

est.hud = true // should hud be enabled?