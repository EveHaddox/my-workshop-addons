ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Heavy Armor" // name used by the suit
ENT.Author = "Eve Haddox"
ENT.Category = "Eve"
ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.action = function(ply) ply:SetMaxArmor(200) ply:SetArmor(200) end // effects on equiping