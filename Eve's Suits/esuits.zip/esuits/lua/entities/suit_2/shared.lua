ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Medium Armor" // name used by the suit
ENT.Author = "Eve Haddox"
ENT.Category = "Eve"
ENT.Spawnable = true
ENT.AdminSpawnable = true

ENT.action = function(ply) ply:SetMaxArmor(150) ply:SetArmor(150) end // effects on equiping